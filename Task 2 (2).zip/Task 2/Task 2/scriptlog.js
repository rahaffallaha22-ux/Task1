let form = document.getElementById("Form");
form.addEventListener("submit", function(event){
    event.preventDefault();
    let email = document.getElementById("email").value;
    let password = document.getElementById("password").value;
    let savedUser = JSON.parse(localStorage.getItem("user"));
    if(savedUser &&
       email === savedUser.email &&
       password === savedUser.password)
    {
        document.getElementById("success").innerHTML =
        "Login Successful!";
    }
    else{

        document.getElementById("success").innerHTML =
        "Wrong Email or Password!";
    }
});
function goToRegister(){
    window.location.href = "Registration.html";
}