let form = document.getElementById("Form");

form.addEventListener("submit", function(event){

    event.preventDefault();

    let user = {
        userId: document.getElementById("userId").value,
        password: document.getElementById("password").value,
        name: document.getElementById("name").value,
        email: document.getElementById("email").value
    };


    localStorage.setItem("user", JSON.stringify(user));


    document.getElementById("success").innerHTML =
    "Registration Successful!";

});


function gologin(){

    window.location.href = "login.html";

}